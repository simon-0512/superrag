/** @constructor */
function Word() {
}

Word.prototype.reverse = function() {
}

Word.prototype.reverse.utf8 = function() {
}